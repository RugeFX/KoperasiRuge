
<?php $__env->startSection('content'); ?>
<title>Edit</title>

<h2 style="text-align: center; color: #00901C;">Edit Jenis Simpanan</h2>
<a href="<?php echo e(route('jen.index')); ?>" class="btn btn-secondary">Kembali</a>

<?php if($errors->any()): ?>
<div class="alert alert-danger">
    <strong>Waduh!</strong> Input gagal. <br><br>
    <ul>
        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
</div>
<?php endif; ?>

<form action="<?php echo e(route('jen.update', $jen->id)); ?>" method="POST">
<?php echo csrf_field(); ?>
<?php echo method_field('PUT'); ?>

        <div class="main-container">
            <div class="form-grid">
                <div class="form-title">
                    <strong>ID Jenis :</strong>
                </div>
                <div class="form-item">
                    <input type="text" name="idJenis"  placeholder="ID Jenis" value="<?php echo e($jen->idJenis); ?>">
                </div>
                <div class="form-title">
                    <strong>Jenis Simpanan :</strong>
                </div>
                <div class="form-item">
                    <input type="text" name="jenisSimpanan"  placeholder="Jenis Simpanan" value="<?php echo e($jen->jenisSimpanan); ?>">
                </div>
                <div class="form-title">
                    <strong>Jumlah :</strong>
                </div>
                <div class="form-item">
                    <input type="text" name="jumlah"  placeholder="Jumlah" value="<?php echo e($jen->jumlah); ?>">
                </div>
            </div>
        </div>
        <div style="display: flex; justify-content: center; margin-top: .5rem;">
            <button type="submit" class="action-btn" style="text-align: center; border: none; cursor: pointer; padding: .5rem;">Simpan</button>
        </div>
</form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\lenovo\Documents\TUGAS\12\PWPB\LARAVEL\koperasi\resources\views/jen/edit.blade.php ENDPATH**/ ?>