<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Noto+Sans&display=swap');
    </style>
    <link rel="stylesheet" href="<?php echo e(url('/style.css')); ?>">
    <script src="<?php echo e(asset('js/jquery.min.js')); ?>"></script>
</head>
<body>
    <div id="mySidebar" class="sidebar">
        <a href="javascript:void(0)" class="closebtn" style="text-align: center;" onclick="closeNav()">×</a>
        <a href="<?php echo e(route('angg.index')); ?>">Anggota</a>
        <a href="<?php echo e(route('jen.index')); ?>">Jenis Simpanan</a>
        <a href="<?php echo e(route('user.index')); ?>">Pengguna</a>
        <a href="<?php echo e(route('simp.index')); ?>">Simpanan</a>
        <a href="<?php echo e(route('pinj.index')); ?>">Pinjaman</a>
        <a href="<?php echo e(route('dpin.index')); ?>">Bayar Pinjaman</a>
        <a href="<?php echo e(route('peng.index')); ?>">Pengambilan</a>
    </div>
    <button class="openbtn" onclick="openNav()">☰</button> 
    <div class="main-content" id="main">
        <?php echo $__env->yieldContent('content'); ?>
    </div>
    <script>
        function openNav() {
          document.getElementById("mySidebar").style.width = "200px";
          document.getElementById("main").style.marginLeft = "200px";
        }
        
        function closeNav() {
          document.getElementById("mySidebar").style.width = "0";
          document.getElementById("main").style.marginLeft= "3rem";
        }
    </script>
</body>
</html><?php /**PATH C:\Users\lenovo\Documents\TUGAS\12\PWPB\LARAVEL\koperasi\resources\views/template.blade.php ENDPATH**/ ?>