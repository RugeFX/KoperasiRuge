
<?php $__env->startSection('content'); ?>
<title>Anggota Index</title>
<div id="mySidebar" class="sidebar">
    <a href="javascript:void(0)" class="closebtn" onclick="closeNav()">×</a>
    <a href="#">About</a>
    <a href="#">Services</a>
    <a href="#">Clients</a>
    <a href="#">Contact</a>
</div>
<div class="main-content" id="main">
    <h1>CRUD Anggota</h1>
    <a href="/">Home</a>
    <a href="<?php echo e(route('anggotas.create')); ?>">Create Anggota</a>

    <table>
        <tr>
            <th>No</th>
            <th>No Anggota</th>
            <th>Nama</th>
            <th>Jenis Kelamin</th>
            <th>No Telpon</th>
        </tr>
        <?php $__currentLoopData = $anggotas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $anggotafor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
        <td><?php echo e(++$i); ?></td>
        <td><?php echo e($anggotafor->noAnggota); ?></td>
        <td><?php echo e($anggotafor->namaAnggota); ?></td>
        <td><?php echo e($anggotafor->jKelamin); ?></td>
        <td><?php echo e($anggotafor->noTelpon); ?></td>
        <td>
            <form action="<?php echo e(route('anggotas.destroy', $anggotafor->id)); ?>" method="post">
                <a href="<?php echo e(route('anggotas.show', $anggotafor->id)); ?>"">Show</a>
                <a href="<?php echo e(route('anggotas.edit', $anggotafor->id)); ?>">Edit</a>

                <?php echo csrf_field(); ?>
                <?php echo method_field('DELETE'); ?>
                <button type="submit" onclick="return confirm('Apakah anda yakin ingin menghapus data ini?')">Delete</button>
            </form>
        </td>
    </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>
</div>
<?php echo $anggotas->links(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\lenovo\Documents\TUGAS\12\PWPB\LARAVEL\koperasi\resources\views/anggotas/index.blade.php ENDPATH**/ ?>