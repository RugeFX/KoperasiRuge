
<?php $__env->startSection('content'); ?>
<title>Simpanan Index</title>

    <h1 style="text-align: center; color: #00901C;">Table Simpanan</h1>
    <div class="main-container">
        <div class="top-btn-container">
            <a href="/" class="top-btn">
                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-house-door-fill" viewBox="0 0 16 16">
                    <path d="M6.5 14.5v-3.505c0-.245.25-.495.5-.495h2c.25 0 .5.25.5.5v3.5a.5.5 0 0 0 .5.5h4a.5.5 0 0 0 .5-.5v-7a.5.5 0 0 0-.146-.354L13 5.793V2.5a.5.5 0 0 0-.5-.5h-1a.5.5 0 0 0-.5.5v1.293L8.354 1.146a.5.5 0 0 0-.708 0l-6 6A.5.5 0 0 0 1.5 7.5v7a.5.5 0 0 0 .5.5h4a.5.5 0 0 0 .5-.5z"/>
                </svg>
            </a>
        </div>
        <?php if($errors->any()): ?>
        <div class="alert alert-danger">
            <strong>Waduh!</strong> Gagal menyimpan.... <br>
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
        <?php endif; ?>
        <form action="<?php echo e(route('simp.store')); ?>" method="post">
            <?php echo csrf_field(); ?>
            <div class="input-form">
                <div class="input-flex-box">
                    <div class="input-box">
                        <label for="noAnggota">No Anggota</label>
                        <input type="search" name="noAnggota" id="noanggota" placeholder="Insert No. Anggota">
                    </div>
                    <div class="input-box">
                        <label for="idSimpanan">ID Simpanan</label>
                        <input type="text" name="idSimpanan" id="idsimpan" placeholder="Insert ID Simpanan">
                    </div>
                    <div class="input-box">
                        <label for="tanggal">Tanggal</label>
                        <input type="date" name="tanggal" id="tanggal" value="<?php echo e(date("Y-m-d")); ?>">
                    </div>
                </div>
                <div class="input-flex-box">
                    <div class="input-box">
                        <label for="idJenis">Jenis Simpanan</label>
                        <select name="idJenis" id="idJenis">
                            <option>Select Jenis</option>
                            <?php $__currentLoopData = $jsimp; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $jenis): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($jenis->idJenis); ?>"><?php echo e($jenis->jenisSimpanan); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <div class="input-box">
                        <label for="jumlah">Jumlah</label>
                        <input type="number" name="jumlah" id="jumlah" placeholder="Insert Jumlah Simpanan" readonly>
                    </div>
                    <div class="input-box">
                        <label for="userId">User</label>
                        <input type="text" name="userId" id="userId" placeholder="Insert ID User">
                    </div>
                </div>
            </div>
            <div class="submit-form">
                <button type="submit" class="action-btn" style="border: none; cursor: pointer; padding: .5rem 1rem;">Save</button>
            </div>
            <div class="user-info" id="info" style="display: none;">

            </div>
        </form>
            <table class="tablecrud">
                <thead class="header">
                    <tr>
                        <th>No</th>
                        <th>ID Simpanan</th>
                        <th>Tanggal</th>
                        <th>No Anggota</th>
                        <th>ID Jenis</th>
                        <th>Jumlah</th>
                        <th>ID User</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody id="all">
                    <?php $__currentLoopData = $simp; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $simpsfor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($i++); ?></td>
                    <td><?php echo e($simpsfor->idSimpanan); ?></td>
                    <td><?php echo e($simpsfor->tanggal); ?></td>
                    <td><?php echo e($simpsfor->noAnggota); ?></td>
                    <td><?php echo e($simpsfor->jenisSimpanan); ?></td>
                    <td><?php echo e($simpsfor->jumlah); ?></td>
                    <td><?php echo e($simpsfor->userId); ?></td>
                    <td>
                        <form action="<?php echo e(route('simp.destroy', $simpsfor->id)); ?>" method="post">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button class="remove-btn" type="submit" onclick="return confirm('Apakah anda yakin ingin menghapus data ini?')">
                                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-trash-fill" viewBox="0 0 16 16">
                                    <path d="M2.5 1a1 1 0 0 0-1 1v1a1 1 0 0 0 1 1H3v9a2 2 0 0 0 2 2h6a2 2 0 0 0 2-2V4h.5a1 1 0 0 0 1-1V2a1 1 0 0 0-1-1H10a1 1 0 0 0-1-1H7a1 1 0 0 0-1 1H2.5zm3 4a.5.5 0 0 1 .5.5v7a.5.5 0 0 1-1 0v-7a.5.5 0 0 1 .5-.5zM8 5a.5.5 0 0 1 .5.5v7a.5.5 0 0 1-1 0v-7A.5.5 0 0 1 8 5zm3 .5v7a.5.5 0 0 1-1 0v-7a.5.5 0 0 1 1 0z"/>
                                </svg>
                            </button>
                        </form>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td colspan="5">Total : </td>
                    <?php $__currentLoopData = $total; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $totals): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <td><?php echo e($totals->total); ?></td>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tr>
                </tbody>  
                <tbody id="search">

                </tbody>
            </table>
    
    </div>
    <script>
        $(document).ready(function(){
            $("#noanggota").keyup(function(){
                $value=$(this).val();
                
                if($value){
                    $('#all').hide()
                    $('#search').show()
                }else{
                    $('#all').show()
                    $('#search').hide()
                }

                $.ajax({
                    type: "get",
                    url: "<?php echo e(URL::to('noanggota')); ?>",
                    data: {'noanggota':$value},
                    
                    success: function (data) {
                        $('#search').html(data);
                    }
                });
            })

            $("#idJenis").change(function() {
                let value = $(this).val();
                $.ajax({
                    type:'get',
                    url: '<?php echo e(URL::to("jenis")); ?>',
                    dataType: 'json',
                    data: {
                        'jenis': value
                    },
                    success: function(data) {
                        $('#jumlah').val(data['data'])

                        if(data['read']){
                            $("#jumlah").removeAttr("readonly")
                            $("#jumlah").attr("min", data['min'])
                        }else{
                            $("#jumlah").attr("readonly","")
                            $("#jumlah").removeAttr("min")
                        }
                    }
                });
            })

            $("#noanggota").on('keyup', function(){
                // alert('test');
                let value=$(this).val();

                if(value){
                    $('#info').show();
                } else {
                    $('#info').hide();
                }

                $.ajax({

                    type:'get',
                    url:'<?php echo e(URL::to('infoangg')); ?>',
                    data:{'infoangg':value},

                    success:function(data){
                        // console.log(data);
                        $('#info').html(data);
                    }

                });
            })
        })
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\lenovo\Documents\TUGAS\12\PWPB\LARAVEL\koperasi\resources\views/simp/index.blade.php ENDPATH**/ ?>