
<?php $__env->startSection('content'); ?>
<title>Create</title>
<h2 style="text-align: center; color: #00901C;">Create Jenis Simpanan</h2>
<a href="<?php echo e(route('jenis.index')); ?>" class="btn btn-secondary">Kembali</a>

<?php if($errors->any()): ?>
<div class="alert alert-danger">
    <strong>Waduh!</strong> Input gagal. <br><br>
    <ul>
        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
</div>
<?php endif; ?>
        
<form action="<?php echo e(route('jenis.store')); ?>" method="POST">
    <?php echo csrf_field(); ?>
        
    <div class="main-container">
        <div class="form-grid">
            <div class="form-title">
                <strong>ID Jenis :</strong>
            </div>
            <div class="form-item">
                <input type="text" name="idJenis"  placeholder="ID Jenis">
            </div>
            <div class="form-title">
                <strong>Jenis Simpanan :</strong>
            </div>
            <div class="form-item">
                <input type="text" name="jenisSimpanan"  placeholder="Jenis Simpanan">
            </div>
            <div class="form-title">
                <strong>Jumlah :</strong>
            </div>
            <div class="form-item">
                <input type="text" name="jumlah"  placeholder="Jumlah">
            </div>
        </div>
        <div style="display: flex; justify-content: center; margin-top: .5rem;">
            <button type="submit" class="action-btn" style="text-align: center; border: none; cursor: pointer; padding: .5rem;">Simpan</button>
        </div>
    </div>
</form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\lenovo\Documents\TUGAS\12\PWPB\LARAVEL\koperasi\resources\views/jenis/create.blade.php ENDPATH**/ ?>