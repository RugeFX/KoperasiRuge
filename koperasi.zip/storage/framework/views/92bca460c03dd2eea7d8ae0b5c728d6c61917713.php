<?php $__env->startSection('content'); ?>
    <title>Koperasi - Homepage</title>
    <div class="flex flex-col h-full justify-center items-center">
        <h1 class="text-5xl text-green-900 font-bold">Welcome to Koperasi Ruge</h1>
        <div class="text-green-900">
            Fast. Reliable. Trusted
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\TUGASSSS\PWPB\12\larapel\koperasi\resources\views/welcome.blade.php ENDPATH**/ ?>