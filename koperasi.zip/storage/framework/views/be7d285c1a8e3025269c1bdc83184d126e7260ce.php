<?php $__env->startSection('content'); ?>
    <title>Koperasi - Homepage</title>
</head>
<body>
    <h1>Welcome
    </h1>
</body>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\lenovo\Documents\TUGAS\12\PWPB\LARAVEL\koperasi\resources\views/welcome.blade.php ENDPATH**/ ?>