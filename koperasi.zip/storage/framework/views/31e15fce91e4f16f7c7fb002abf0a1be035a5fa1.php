
<?php $__env->startSection('content'); ?>
<title>Show</title>

<h2 style="text-align: center; color: #00901C;">Show Anggota</h2>
<a href="<?php echo e(route('angg.index')); ?>" class="btn btn-secondary">Kembali</a>

<div class="main-container">
    <div class="form-grid">
        <div class="form-title">
            <strong>No Anggota :</strong>
        </div>
        <div class="form-item">
            <?php echo e($angg->noAnggota); ?>

        </div>
        <div class="form-title">
            <strong>Nama Anggota :</strong>
        </div>
        <div class="form-item">
            <?php echo e($angg->namaAnggota); ?>

        </div>
        <div class="form-title">
            <strong>Jenis Kelamin :</strong>
        </div>
        <div class="form-item">
            <?php if($angg->jKelamin === "L"): ?>
                Laki Laki
            <?php elseif($angg->jKelamin === "P"): ?>
                Perempuan
            <?php endif; ?>
        </div>
        <div class="form-title">
            <strong>Tempat Lahir :</strong>
        </div>
        <div class="form-item">
            <?php echo e($angg->tempatLahir); ?>

        </div>
        <div class="form-title">
            <strong>Tanggal Lahir :</strong>
        </div>
        <div class="form-item">
            <?php echo e($angg->tglLahir); ?>

        </div>
        <div class="form-title">
            <strong>Alamat :</strong>
        </div>
        <div class="form-item">
            <?php echo e($angg->alamat); ?>

        </div>
        <div class="form-title">
            <strong>Nomor Telpon :</strong>
        </div>
        <div class="form-item">
            <?php echo e($angg->noTelpon); ?>

        </div> 
        <div class="form-title">
            <strong>No Identitas :</strong>
        </div>
        <div class="form-item">
            <?php echo e($angg->noIdentitas); ?>

        </div>
        <div class="form-title">
            <strong>Password :</strong>
        </div>
        <div class="form-item">
            <?php echo e($angg->password); ?>

        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\lenovo\Documents\TUGAS\12\PWPB\LARAVEL\koperasi\resources\views/angg/show.blade.php ENDPATH**/ ?>