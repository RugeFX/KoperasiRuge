
<?php $__env->startSection('content'); ?>
<title>Edit</title>

<div class="w-full flex justify-center">
    <h1 class="text-3xl font-bold mb-8 text-green-600 ml-0">Edit Anggota</h1>
</div>
<div class="flex gap-2 w-1/3 mb-2">
    <a href="<?php echo e(route('angg.index')); ?>" class="flex gap-2 items-center text-white bg-green-600 hover:bg-green-800 focus:ring-4 focus:outline-none focus:border-green-500 font-medium rounded-lg text-sm px-5 py-2.5 text-center transition duration-300 ease-in-out">
        <i class='bx bx-arrow-back'></i>
        Kembali
    </a>
</div>

<?php if($errors->any()): ?>
<div class="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded relative" role="alert">
    <strong class="font-bold">Waduh!</strong>
    <span class="block sm:inline">Gagal menambah....</span>
    <ul>
        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li>- <?php echo e($error); ?></li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
</div>
<?php endif; ?>

<form action="<?php echo e(route('angg.update', $angg->id)); ?>" method="POST">
<?php echo csrf_field(); ?>
<?php echo method_field('PUT'); ?>

        <div class="mr-2 bg-gray-50 p-4 rounded-xl border border-slate-200">
            <div class="flex justify-center">
                <div class="grid grid-cols-2 mx-10 gap-y-2">
                    <div class="form-title">
                        <strong>No Anggota :</strong>
                    </div>
                    <div class="form-item">
                        <input type="text" name="noAnggota"  placeholder="No Anggota" value="<?php echo e($angg->noAnggota); ?>" class="form-control
                        block
                        w-full
                        px-3
                        py-1.5
                        text-base
                        font-normal
                        text-gray-700
                        bg-white bg-clip-padding
                        border border-solid border-gray-300
                        rounded
                        transition
                        ease-in-out
                        m-0
                        focus:text-gray-700 focus:bg-white focus:border-green-600 focus:outline-none">
                    </div>
                    <div class="form-title">
                        <strong>Nama Anggota :</strong>
                    </div>
                    <div class="form-item">
                        <input type="text" name="namaAnggota"  placeholder="Nama Anggota" value="<?php echo e($angg->namaAnggota); ?>" class="form-control
                        block
                        w-full
                        px-3
                        py-1.5
                        text-base
                        font-normal
                        text-gray-700
                        bg-white bg-clip-padding
                        border border-solid border-gray-300
                        rounded
                        transition
                        ease-in-out
                        m-0
                        focus:text-gray-700 focus:bg-white focus:border-green-600 focus:outline-none">
                    </div>
                    <div class="form-title">
                        <strong>Jenis Kelamin :</strong>
                    </div>
                    <div class="form-item">
                        <input type="radio" name="jKelamin" value="L" 
                        <?php if($angg->jKelamin === "L"): ?>
                        checked
                        <?php endif; ?>
                        >
                        <label for="l">Laki Laki</label>
                    </div>
                    <div class="form-title"></div>
                    <div class="form-item">
                        <input type="radio" name="jKelamin" value="P"
                        <?php if($angg->jKelamin === "P"): ?>
                        checked
                        <?php endif; ?>
                        >
                        <label for="p">Perempuan</label>
                    </div>
                    <div class="form-title">
                        <strong>Tempat Lahir :</strong>
                    </div>
                    <div class="form-item">
                        <input type="text" name="tempatLahir"  placeholder="Kota" value="<?php echo e($angg->tempatLahir); ?>" class="form-control
                        block
                        w-full
                        px-3
                        py-1.5
                        text-base
                        font-normal
                        text-gray-700
                        bg-white bg-clip-padding
                        border border-solid border-gray-300
                        rounded
                        transition
                        ease-in-out
                        m-0
                        focus:text-gray-700 focus:bg-white focus:border-green-600 focus:outline-none">
                    </div>
                    <div class="form-title">
                        <strong>Tanggal Lahir :</strong>
                    </div>
                    <div class="form-item">
                        <input type="date" name="tglLahir"  placeholder="Tanggal Lahir" value="<?php echo e($angg->tglLahir); ?>" class="form-control
                        block
                        w-full
                        px-3
                        py-1.5
                        text-base
                        font-normal
                        text-gray-700
                        bg-white bg-clip-padding
                        border border-solid border-gray-300
                        rounded
                        transition
                        ease-in-out
                        m-0
                        focus:text-gray-700 focus:bg-white focus:border-green-600 focus:outline-none">
                    </div>
                    <div class="form-title">
                        <strong>Alamat :</strong>
                    </div>
                    <div class="form-item">
                        <textarea name="alamat" cols="30" rows="10" class="form-control
                        block
                        w-full
                        resize-none
                        h-24
                        px-3
                        py-1.5
                        text-base
                        font-normal
                        text-gray-700
                        bg-white bg-clip-padding
                        border border-solid border-gray-300
                        rounded
                        transition
                        ease-in-out
                        m-0
                        focus:text-gray-700 focus:bg-white focus:border-green-600 focus:outline-none"><?php echo e($angg->alamat); ?></textarea>
                    </div>
                    <div class="form-title">
                        <strong>Nomor Telpon :</strong>
                    </div>
                    <div class="form-item">
                        <input type="text" name="noTelpon"  placeholder="Nomor Telepon" value="<?php echo e($angg->noTelpon); ?>" class="form-control
                        block
                        w-full
                        px-3
                        py-1.5
                        text-base
                        font-normal
                        text-gray-700
                        bg-white bg-clip-padding
                        border border-solid border-gray-300
                        rounded
                        transition
                        ease-in-out
                        m-0
                        focus:text-gray-700 focus:bg-white focus:border-green-600 focus:outline-none">
                    </div> 
                    <div class="form-title">
                        <strong>No Identitas :</strong>
                    </div>
                    <div class="form-item">
                        <input type="text" name="noIdentitas" placeholder="Nomor Identitas" value="<?php echo e($angg->noIdentitas); ?>" class="form-control
                        block
                        w-full
                        px-3
                        py-1.5
                        text-base
                        font-normal
                        text-gray-700
                        bg-white bg-clip-padding
                        border border-solid border-gray-300
                        rounded
                        transition
                        ease-in-out
                        m-0
                        focus:text-gray-700 focus:bg-white focus:border-green-600 focus:outline-none">
                    </div>
                    <div class="form-title">
                        <strong>Password :</strong>
                    </div>
                    <div class="form-item">
                        <input type="text" name="password" placeholder="Password" value="<?php echo e($angg->password); ?>" class="form-control
                        block
                        w-full
                        px-3
                        py-1.5
                        text-base
                        font-normal
                        text-gray-700
                        bg-white bg-clip-padding
                        border border-solid border-gray-300
                        rounded
                        transition
                        ease-in-out
                        m-0
                        focus:text-gray-700 focus:bg-white focus:border-green-600 focus:outline-none">
                    </div>
                </div>
            </div>
            
            <div class="flex justify-center mt-2">
                <button type="submit" class="flex gap-2 items-center text-white bg-green-600 hover:bg-green-800 focus:ring-4 focus:outline-none focus:border-green-500 font-medium rounded-lg text-sm px-5 py-2.5 text-center transition duration-300 ease-in-out">Simpan</button>
            </div>
        </div>
</form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\TUGASSSS\PWPB\12\larapel\koperasi\resources\views/angg/edit.blade.php ENDPATH**/ ?>