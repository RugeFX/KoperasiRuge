@extends('template')
@section('content')
    <title>Koperasi - Homepage</title>
    <div class="flex flex-col h-full justify-center items-center">
        <h1 class="text-5xl text-green-900 font-bold">Welcome to Koperasi Ruge</h1>
        <div class="text-green-900">
            Fast. Reliable. Trusted
        </div>
    </div>
@endsection